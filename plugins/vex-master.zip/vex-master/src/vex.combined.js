var vex = require('./vex')
vex.registerPlugin(require('vex-dialog'))
module.exports = vex
